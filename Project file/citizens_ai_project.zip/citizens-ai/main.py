import json
from citizens_ai.feedback_handler import parse_feedback
from citizens_ai.ai_engine import rank_feedback

def main():
    with open("data/sample_feedback.json") as f:
        data = json.load(f)

    feedback_list = parse_feedback(data)
    ranked = rank_feedback(feedback_list)

    print("Ranked Feedback:")
    for fb, score in ranked:
        print(f"[{score:.2f}] {fb}")

if __name__ == "__main__":
    main()
