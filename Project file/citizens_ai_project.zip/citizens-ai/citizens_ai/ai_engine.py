from .sentiment import analyze_sentiment

def rank_feedback(feedback_list):
    scored = [(fb, analyze_sentiment(fb)) for fb in feedback_list]
    return sorted(scored, key=lambda x: x[1], reverse=True)
