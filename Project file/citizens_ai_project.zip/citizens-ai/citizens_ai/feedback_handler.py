def parse_feedback(data):
    return [entry["text"] for entry in data if "text" in entry]
